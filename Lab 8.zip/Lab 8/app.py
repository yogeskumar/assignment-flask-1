from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_session import Session
from datetime import datetime
import os, atexit

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a secret key for session security
app.config['SESSION_TYPE'] = 'filesystem'  # Choose a session storage type (e.g., filesystem, redis)
Session(app)

# Dummy data for registered users
registered_users = {'user1': {'password': 'password1', 'common_password': False},
                    'user2': {'password': 'password2', 'common_password': False}}

# Common passwords list
with open('CommonPasswords.txt', 'r') as file:
    common_passwords = [line.strip() for line in file]

# Logger function to log failed login attempts
def log_failed_login(username, ip_address):
    with open('failed_login.log', 'a') as file:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        file.write(f"{timestamp} - Failed login attempt for user '{username}' from IP address {ip_address}\n")

# Define routes
@app.route('/')
def index():
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return render_template('index.html', current_datetime=current_datetime)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if len(password) < 12:
            flash('Password must be at least 12 characters long', 'error')
        elif not any(char.isupper() for char in password):
            flash('Password must contain at least one uppercase letter', 'error')
        elif not any(char.islower() for char in password):
            flash('Password must contain at least one lowercase letter', 'error')
        elif not any(char.isdigit() for char in password):
            flash('Password must contain at least one digit', 'error')
        elif not any(char in '!@#$%^&*()-_=+{}[]|;:,.<>?/~' for char in password):
            flash('Password must contain at least one special character', 'error')
        else:
            registered_users[username] = {'password': password, 'common_password': False}
            flash('User registered successfully', 'success')
            return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if the username exists in registered_users
        if username in registered_users:
            # Get the user data (dictionary containing password)
            user_data = registered_users[username]
            # Check if the provided password matches the stored password
            if user_data['password'] == password:
                flash('Login successful', 'success')
                session['username'] = username
                return redirect(url_for('index'))
        
        # If username doesn't exist or password doesn't match
        flash('Invalid username or password', 'error')
    
    return render_template('login.html')

@app.route('/update_password', methods=['GET', 'POST'])
def update_password():
   #  print(request.method)  # Print the request method for debugging
   #  if request.method == 'POST':
   #      print(request.form)
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']
        if current_password != registered_users[session['username']]['password']:
            flash('Incorrect current password', 'error')
        elif new_password != confirm_password:
            flash('New password and confirm password do not match', 'error')
        elif len(new_password) < 12:
            flash('Password must be at least 12 characters long', 'error')
        elif not any(char.isupper() for char in new_password):
            flash('Password must contain at least one uppercase letter', 'error')
        elif not any(char.islower() for char in new_password):
            flash('Password must contain at least one lowercase letter', 'error')
        elif not any(char.isdigit() for char in new_password):
            flash('Password must contain at least one digit', 'error')
        elif not any(char in '!@#$%^&*()-_=+{}[]|;:,.<>?/~' for char in new_password):
            flash('Password must contain at least one special character', 'error')
        elif new_password in common_passwords:
            flash('Password is too common, please choose a different one', 'error')
        else:
            registered_users[session['username']]['password'] = new_password
            flash('Password updated successfully', 'success')
            return redirect(url_for('index'))
    
    return render_template('update_password.html')

def cleanup(folder_path):
    try:
        for file_name in os.listdir(folder_path):
            file_path = os.path.join(folder_path, file_name)
            if os.path.isfile(file_path):
                os.unlink(file_path)
    except Exception as e:
        print(f"Error deleting files: {e}")

atexit.register(cleanup, './flask_session')


if __name__ == '__main__':
    app.run(debug=True)

